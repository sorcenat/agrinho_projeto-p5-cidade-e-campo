let stage = "campo"; // Fase inicial do campo
let transitionSpeed = 0.02; // Velocidade de transição

function setup() {
  createCanvas(900, 600);
}

function draw() {
  if (stage === "campo") {
    drawCampo();
  } else if (stage === "cidade") {
    drawCidade();
  }
  
  transitionEffect();
}

function drawCampo() {
  background(100, 200, 100); // Cor verde para o campo
  fill(255, 215, 0); // Cor amarela para o sol
  ellipse(700, 100, 100, 100); // Sol

  fill(0, 128, 0); // Cor das árvores
  rect(100, 300, 100, 200); // Árvore 1
  rect(300, 350, 100, 200); // Árvore 2
}

function drawCidade() {
  background(200, 200, 200); // Cor rosa para a cidade
  fill(169, 169, 169); // Cor dos prédios
  rect(50, 200, 100, 400); // Prédio 1
  rect(200, 150, 150, 450); // Prédio 2
  rect(400, 180, 120, 500); // Prédio 3

  fill(255, 255, 0); // Cor do sol
  ellipse(700, 100, 100, 100); // Sol
}

function transitionEffect() {
  // Simulando a transição do campo para a cidade
  if (stage === "campo" && frameCount % 100 === 0) {
    stage = "cidade";
  }
}
